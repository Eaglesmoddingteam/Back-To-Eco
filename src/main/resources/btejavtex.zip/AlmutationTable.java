package alm;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;

/**
 * AlmutationTable - Igrek02
 * Created using Tabula 6.0.0
 */
public class AlmutationTable extends ModelBase {
    public ModelRenderer Base;
    public ModelRenderer Bigleg;
    public ModelRenderer tabletop;
    public ModelRenderer Desktop;
    public ModelRenderer leg1;
    public ModelRenderer leg2;
    public ModelRenderer leghelp;

    public AlmutationTable() {
        this.textureWidth = 64;
        this.textureHeight = 80;
        this.leg2 = new ModelRenderer(this, 0, 0);
        this.leg2.setRotationPoint(-3.0F, 0.0F, -15.0F);
        this.leg2.addBox(-1.0F, 0.0F, -1.0F, 2, 4, 2, 0.0F);
        this.tabletop = new ModelRenderer(this, 0, 0);
        this.tabletop.setRotationPoint(0.0F, -8.0F, 0.0F);
        this.tabletop.addBox(-8.0F, -4.0F, -8.0F, 16, 4, 16, 0.0F);
        this.Desktop = new ModelRenderer(this, 0, 51);
        this.Desktop.setRotationPoint(0.0F, -9.2F, -13.1F);
        this.Desktop.addBox(-7.0F, -7.0F, -3.0F, 14, 14, 3, 0.0F);
        this.setRotateAngle(Desktop, -0.4553564018453205F, 0.0F, 0.0F);
        this.leg1 = new ModelRenderer(this, 0, 0);
        this.leg1.setRotationPoint(3.0F, 0.0F, -15.0F);
        this.leg1.addBox(-1.0F, 0.0F, -1.0F, 2, 4, 2, 0.0F);
        this.Base = new ModelRenderer(this, 0, 0);
        this.Base.setRotationPoint(0.0F, 20.0F, 16.0F);
        this.Base.addBox(-8.0F, 0.0F, -8.0F, 16, 4, 16, 0.0F);
        this.Bigleg = new ModelRenderer(this, 0, 20);
        this.Bigleg.setRotationPoint(0.0F, 0.0F, 0.0F);
        this.Bigleg.addBox(-4.0F, -8.0F, -16.0F, 8, 8, 20, 0.0F);
        this.leghelp = new ModelRenderer(this, 0, 10);
        this.leghelp.setRotationPoint(0.0F, 1.6F, -15.0F);
        this.leghelp.addBox(-3.0F, -0.5F, -0.5F, 6, 1, 1, 0.0F);
        this.Bigleg.addChild(this.leg2);
        this.Base.addChild(this.tabletop);
        this.Bigleg.addChild(this.Desktop);
        this.Bigleg.addChild(this.leg1);
        this.Base.addChild(this.Bigleg);
        this.Bigleg.addChild(this.leghelp);
    }

    @Override
    public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) { 
        this.Base.render(f5);
    }

    /**
     * This is a helper function from Tabula to set the rotation of model parts
     */
    public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
        modelRenderer.rotateAngleX = x;
        modelRenderer.rotateAngleY = y;
        modelRenderer.rotateAngleZ = z;
    }
}
